Video
=====
.. automodule:: subliminal.video
    :exclude-members: VIDEO_EXTENSIONS

    .. autodata:: VIDEO_EXTENSIONS
        :annotation:
