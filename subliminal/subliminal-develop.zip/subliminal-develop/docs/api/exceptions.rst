Exceptions
==========
.. automodule:: subliminal.exceptions
