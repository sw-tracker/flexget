CLI
===
.. automodule:: subliminal.cli
