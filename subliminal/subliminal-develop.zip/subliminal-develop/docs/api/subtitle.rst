Subtitle
========
.. automodule:: subliminal.subtitle
    :exclude-members: SUBTITLE_EXTENSIONS

    .. autodata:: SUBTITLE_EXTENSIONS
        :annotation:
