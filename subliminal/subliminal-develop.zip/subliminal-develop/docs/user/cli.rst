.. _cli:

CLI
===

subliminal
----------
.. program-output:: subliminal --help


subliminal download
-------------------
.. program-output:: subliminal download --help


subliminal cache
----------------
.. program-output:: subliminal cache --help
